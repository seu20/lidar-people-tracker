network/TCP/TCPReceiver.o: network/TCP/TCPReceiver.cpp \
 network/TCP/TCPReceiver.h Protocol.h
network/TCP/TCPReceiver.h:
Protocol.h:
