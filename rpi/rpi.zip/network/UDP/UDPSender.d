network/UDP/UDPSender.o: network/UDP/UDPSender.cpp \
 network/UDP/UDPSender.h Protocol.h
network/UDP/UDPSender.h:
Protocol.h:
