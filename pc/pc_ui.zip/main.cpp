#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_opengl3.h"
#include <SDL.h>
#include <SDL_opengl.h>

#include "SharedState.h"
#include "UDPReceiver.h"
#include "TCPSender.h"
#include "Protocol.h"

#include <cmath>
#include <iostream>

#define RPI_IP    "100.69.228.12"   // RPi Tailscale IP - 실제 값으로 교체
#define TCP_PORT  2000
#define UDP_PORT  3000

// 라이다 좌표(m) -> 화면 픽셀 변환 (원점: 캔버스 기준점)
static ImVec2 worldToScreen(float x, float y, ImVec2 origin, float scale)
{
    return ImVec2(origin.x + y * scale, origin.y - x * scale);  // x: 전방, y: 좌우
}

int main(int, char**)
{
    // ---- SDL2 + OpenGL 초기화 ----
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) {
        std::cerr << "SDL_Init failed: " << SDL_GetError() << std::endl;
        return -1;
    }
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);

    SDL_Window *window = SDL_CreateWindow("LiDAR Viewer",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 800,
        SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE);
    SDL_GLContext gl_context = SDL_GL_CreateContext(window);
    SDL_GL_MakeCurrent(window, gl_context);
    SDL_GL_SetSwapInterval(1);  // vsync

    // ---- ImGui 초기화 ----
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui_ImplSDL2_InitForOpenGL(window, gl_context);
    ImGui_ImplOpenGL3_Init("#version 150");

    // ---- 네트워크 초기화 ----
    SharedState shared_state;
    UDPReceiver udp_receiver(UDP_PORT, &shared_state);
    udp_receiver.start();

    // TCP는 RPi가 TCPReceiver::WaitConnection()으로 대기 중이어야 연결 성공함
    // (RPi 프로그램을 먼저 실행해둔 상태에서 PC 프로그램을 실행할 것)
    TCPSender tcp_Sender(RPI_IP, TCP_PORT);
    bool is_running = false;

    float scale = 15.0f;   // 픽셀/미터
    bool app_running = true;

    while (app_running)
    {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            ImGui_ImplSDL2_ProcessEvent(&event);
            if (event.type == SDL_QUIT) app_running = false;
        }

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        ViewState snapshot = shared_state.getSnapshot();

        // ---- 디버그 로그 ----
        static int log_counter = 0;
        if (++log_counter % 60 == 0)   // 매 프레임마다 찍으면 너무 많으니 60프레임(약 1초)마다 한 번
        {
            std::cout << "[DEBUG] points=" << snapshot.points.size()
                    << " objects=" << snapshot.objects.size()
                    << " background=" << snapshot.background.size() << std::endl;

            if (!snapshot.points.empty())
            {
                std::cout << "[DEBUG] first point: x=" << snapshot.points[0].x
                        << " y=" << snapshot.points[0].y << std::endl;
            }

            if (!snapshot.objects.empty())
            {
                std::cout << "[DEBUG] first object: id=" << snapshot.objects[0].id
                        << " x=" << snapshot.objects[0].x
                        << " y=" << snapshot.objects[0].y << std::endl;
            }
        }

        // ---- 컨트롤 패널 ----
        ImGui::Begin("Control");

        if (ImGui::Button(is_running ? "STOP" : "START"))
        {
            if (is_running) {
                tcp_Sender.sendStop();
                is_running = false;
            } else {
                tcp_Sender.sendStart();
                is_running = true;
            }
        }
        ImGui::SameLine();
        ImGui::TextColored(is_running ? ImVec4(0.3f, 1.0f, 0.3f, 1.0f) : ImVec4(1.0f, 0.3f, 0.3f, 1.0f),
                            is_running ? "Running" : "Stopped");

        ImGui::SliderFloat("Zoom (px/m)", &scale, 2.0f, 100.0f);
        ImGui::Text("Points: %zu  Objects: %zu", snapshot.points.size(), snapshot.objects.size());
        ImGui::Text("Last Point FrameId: %u  Last Object FrameId: %u",
                     snapshot.lastPointFrameId, snapshot.lastObjectFrameId);

        ImGui::Text("Points: %zu  Objects: %zu", snapshot.points.size(), snapshot.objects.size());

        // 이 줄 추가
        if (!snapshot.points.empty()) {
            ImGui::Text("First point: x=%.3f y=%.3f", snapshot.points[0].x, snapshot.points[0].y);
        }

        ImGui::End();

        // ---- 시각화 캔버스 ----
        ImGui::SetNextWindowPos(ImVec2(0, 150), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(1280, 650), ImGuiCond_FirstUseEver);
        ImGui::Begin("LiDAR View");

        ImDrawList *draw_list = ImGui::GetWindowDrawList();
        ImVec2 canvas_pos = ImGui::GetCursorScreenPos();
        ImVec2 canvas_size = ImGui::GetContentRegionAvail();
        // 후 (정중앙 - 360도 전체가 화면 안에 들어옴)
        ImVec2 origin(canvas_pos.x + canvas_size.x * 0.5f, canvas_pos.y + canvas_size.y * 0.5f);

        draw_list->AddRectFilled(canvas_pos,
            ImVec2(canvas_pos.x + canvas_size.x, canvas_pos.y + canvas_size.y),
            IM_COL32(20, 20, 20, 255));

        // 배경 (연회색 점들)
        size_t bin_count = snapshot.background.size();
        for (size_t i = 0; i < bin_count; ++i)
        {
            float angle = (2.0f * (float)M_PI * (float)i) / (float)bin_count;
            float dist = snapshot.background[i] / 100.0f;  // BackgroundModel이 cm 단위라면 m로 변환
            ImVec2 p = worldToScreen(dist * std::cos(angle), dist * std::sin(angle), origin, scale);
            draw_list->AddCircleFilled(p, 1.5f, IM_COL32(100, 100, 100, 150));
        }

        // foreground 포인트 (흰색 점)
        for (const auto &pt : snapshot.points)
        {
            ImVec2 p = worldToScreen(pt.x, pt.y, origin, scale);
            draw_list->AddCircleFilled(p, 2.0f, IM_COL32(255, 255, 255, 255));
        }

        // 추적 객체 (빨간 원 + id + 속도 화살표)
        for (const auto &obj : snapshot.objects)
        {
            ImVec2 p = worldToScreen(obj.x, obj.y, origin, scale);
            draw_list->AddCircle(p, 10.0f, IM_COL32(255, 80, 80, 255), 0, 2.0f);

            char label[16];
            snprintf(label, sizeof(label), "#%d", obj.id);
            draw_list->AddText(ImVec2(p.x + 12, p.y - 8), IM_COL32(255, 255, 0, 255), label);

            ImVec2 vel_end = worldToScreen(obj.x + obj.vx * 0.5f, obj.y + obj.vy * 0.5f, origin, scale);
            draw_list->AddLine(p, vel_end, IM_COL32(255, 80, 80, 255), 2.0f);
        }

        // 센서 원점 표시
        draw_list->AddCircleFilled(origin, 4.0f, IM_COL32(0, 200, 255, 255));

        ImGui::End();

        // ---- 렌더 ----
        ImGui::Render();
        glViewport(0, 0, (int)ImGui::GetIO().DisplaySize.x, (int)ImGui::GetIO().DisplaySize.y);
        glClearColor(0.05f, 0.05f, 0.05f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        SDL_GL_SwapWindow(window);
    }

    // ---- 종료 처리 ----
    if (is_running) {
        tcp_Sender.sendStop();
    }
    udp_receiver.stop();

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    SDL_GL_DeleteContext(gl_context);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}