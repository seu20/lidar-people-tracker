#pragma once
#include "Protocol.h"
#include <string>

class TCPSender {
private:
    int sockfd;

public:
    TCPSender(const std::string &ip, int port);
    ~TCPSender();

    TCPSender(const TCPSender&) = delete;
    TCPSender& operator=(const TCPSender&) = delete;

    void sendStart();
    void sendStop();
};