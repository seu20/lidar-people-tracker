#include "TCPSender.h"
#include <cstring>
#include <iostream>
#include <unistd.h>
#include <arpa/inet.h>

TCPSender::TCPSender(const std::string &ip, int port)
{
    sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sockfd == -1) {
        perror("TCP socket creation failed");
        exit(1);
    }

    struct sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip.c_str(), &addr.sin_addr) <= 0) {
        perror("Invalid RPi address");
        exit(1);
    }

    // RPi가 TCPReceiver::WaitConnection()에서 accept() 대기 중이어야 연결됨
    if (connect(sockfd, (struct sockaddr*)&addr, sizeof(addr)) == -1) {
        perror("Connect to RPi failed");
        exit(1);
    }

    std::cout << "Connected to RPi at " << ip << ":" << port << std::endl;
}

TCPSender::~TCPSender()
{
    if (sockfd >= 0) close(sockfd);
}

void TCPSender::sendStart()
{
    TCPFrame frame{ TCPCmdType::START };
    send(sockfd, &frame, sizeof(frame), 0);
}

void TCPSender::sendStop()
{
    TCPFrame frame{ TCPCmdType::STOP };
    send(sockfd, &frame, sizeof(frame), 0);
}